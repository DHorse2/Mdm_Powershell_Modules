---
external help file: poshfunctions-help.xml
Module Name: poshfunctions
online version: 
schema: 2.0.0
---

# Update-ExplorerIcon

## SYNOPSIS

Updates Explorer icons

## SYNTAX

### __AllParameterSets

```
Update-ExplorerIcon [<CommonParameters>]
```

## DESCRIPTION

Updates Explorer icons


## EXAMPLES


## PARAMETERS


### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## NOTES

Source: https://community.idera.com/database-tools/powershell/powertips/b/tips/posts/refreshing-icon-cache


## RELATED LINKS

Fill Related Links Here

