# Automation

Those a useful helper scripts.