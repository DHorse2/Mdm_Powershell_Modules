iex "& { $(irm 'https://raw.githubusercontent.com/springcomp/my-box/main/bootstrap/powershell.ps1') }"

iex "& { $(irm 'https://raw.githubusercontent.com/springcomp/my-box/main/git.ps1') }"
iex "& { $(irm 'https://raw.githubusercontent.com/springcomp/my-box/main/visual-studio-code.ps1') }"
