# Bootstrapping

Bootstrapping first installs some prerequisite software.

```pwsh
iex "& { $(irm 'https://raw.githubusercontent.com/springcomp/my-box/main/bootstrap/powershell.ps1') }"
```